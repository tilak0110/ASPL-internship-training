package com.example.Tudu.serviceImpl;

import com.example.Tudu.entities.User;
import com.example.Tudu.repositories.UserRepository;
import com.example.Tudu.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final AuthenticationManager authenticationManager;
    private final JWTServiceImpl jwtService;
    private final BCryptPasswordEncoder  encoder = new BCryptPasswordEncoder(12);

    @Autowired
    public UserServiceImpl(UserRepository userRepository, AuthenticationManager authenticationManager, JWTServiceImpl jwtService) {
        this.userRepository = userRepository;
        this.authenticationManager=authenticationManager;
        this.jwtService = jwtService;
    }

    @Override
    public User saveUser(User user) {
        user.setPassword(encoder.encode(user.getPassword()));
        return userRepository.save(user);

    }

    @Override
    public Optional<User> findById(long id) {
        return userRepository.findById(id);
    }

    @Override
    public User updateUser(User optionalUser,User userDetails) {
        optionalUser.setEmail(userDetails.getEmail());
        optionalUser.setUsername(userDetails.getUsername());
        return userRepository.save(optionalUser);
    }


    @Override
    public List<User> getAllUserDetails() {
        return userRepository.findAll();
    }

    @Override
    public void DeleteUserById(long id) {
        userRepository.deleteById(id);
    }

    @Override
    public String verify(User user) {
        String pass = user.getPassword();
        user=userRepository.findByUsername(user.getUsername());
        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(),pass));
        if (authentication.isAuthenticated()){
            String token = jwtService.generateToken(user.getUsername(), user.getEmail(), user.getRole(), 100000);
            return token;
        }
        return "INVALID CREDINALS";
    }

}
