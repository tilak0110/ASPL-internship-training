package com.example.Tudu.services;

import com.example.Tudu.entities.Todo;

import java.util.List;

public interface TodoService {
    Todo addTodoForUser(Todo todo);

    List<Todo> getTodoByUserId(long id);
}
