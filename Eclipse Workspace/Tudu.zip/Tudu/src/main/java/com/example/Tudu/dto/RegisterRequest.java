package com.example.Tudu.dto;


public class RegisterRequest {
    private String username;
    private String password;
    private String email;

    // Getters and Setters
}
