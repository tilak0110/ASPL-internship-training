package com.example.Tudu.dto;

public class LoginRequest {
    private String username;
    private String password;

    // Getters and Setters
}
