package com.example.Tudu.controllers;

import com.example.Tudu.entities.Todo;
import com.example.Tudu.entities.User;
import com.example.Tudu.services.TodoService;
import com.example.Tudu.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/todo")
public class TodoController {
    TodoService todoService;
    UserService userService;

    @Autowired
    public TodoController(TodoService todoService , UserService userService){
        this.todoService=todoService;
        this.userService=userService;
    }
    @GetMapping("/{userId}")
    public ResponseEntity<?> getTodoByUserId(@PathVariable("userId") long id){
        Optional<User> user=userService.findById(id);
        if(user.isPresent()){
            return ResponseEntity.status(HttpStatus.FOUND).body(todoService.getTodoByUserId(id));
        }else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found with id : "+id);
        }
    }

    @PostMapping("/{userId}")
    public ResponseEntity<?> addTodo(@PathVariable("userId") long id, @RequestBody Todo todo){
        Optional<User> optionalUser= userService.findById(id);
        if(optionalUser.isEmpty()){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found with id : "+id);
        }
        todo.setUser(optionalUser.get());
        Todo savedTodo = todoService.addTodoForUser(todo);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedTodo);
    }
//    @PutMapping("/{todoId}")
//    public ResponseEntity<?> updateTodoStatus(@PathVariable ("todoId") long id)


}
