package com.example.Tudu.controllers;


import com.example.Tudu.entities.User;
import com.example.Tudu.exceptions.UserNotFoundException;
import com.example.Tudu.serviceImpl.UserServiceImpl;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@RestController
@RequestMapping("/user")
public class UserController {
    UserServiceImpl userService;

    @Autowired
    public UserController(UserServiceImpl userService){
        this.userService=userService;
    }
    @GetMapping("/admin/getall")
    public ResponseEntity<List<User>> getAllUsers(){
        return ResponseEntity.ok(userService.getAllUserDetails());
    }

    @PostMapping("/login")
    public String login(@RequestBody User user){
        System.out.println(user);

        return userService.verify(user);
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerUser( @Valid @RequestBody User user){
        System.out.println(user);
        User savedUser=userService.saveUser(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedUser);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getUserById(@PathVariable ("id") long id) {
        Optional<User> user=userService.findById(id);
        if(user.isPresent()){
            return ResponseEntity.status(HttpStatus.FOUND).body(user);
        }else {
            throw new UserNotFoundException("User with ID : "+ id+" Not found");
        }
    }
    @PutMapping("/{id}")
    public ResponseEntity<?> updateUser(@PathVariable ("id") long id, @RequestBody User userDetails){
        Optional<User> optionalUser = userService.findById(id);
        if(optionalUser.isEmpty()){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("no User with id : "+id + " Found");
        }
        User updatedUser= userService.updateUser(optionalUser.get(),userDetails);
        return ResponseEntity.ok(updatedUser);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable("id") long id){
        Optional<User> optionalUser = userService.findById(id);
        if(optionalUser.isEmpty()){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("no User with id : "+id + " Found");
        }
        userService.DeleteUserById(id);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("User deleted with id : "+id);
    }
    @GetMapping("/token")
    public String getToken(HttpServletRequest request) {
        CsrfToken csrfToken = (CsrfToken) request.getAttribute("_csrf");
        System.out.println("CSRF Token: " + csrfToken.getToken());
        return "tokenPage"; // return view
    }
    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<String> handleUserNotFound(UserNotFoundException ex){
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }

}
