package com.example.Tudu.serviceImpl;

import com.example.Tudu.entities.Todo;
import com.example.Tudu.repositories.TodoRepository;
import com.example.Tudu.services.TodoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TodoServiceImpl implements TodoService {

    private final TodoRepository todoRepository;

    @Autowired
    public TodoServiceImpl(TodoRepository todoRepository) {
        this.todoRepository = todoRepository;
    }

    @Override
    public Todo addTodoForUser( Todo todo) {
        return todoRepository.save(todo);
    }

    @Override
    public List<Todo> getTodoByUserId(long id) {
        return todoRepository.findAllByUserId(id);
    }
}
