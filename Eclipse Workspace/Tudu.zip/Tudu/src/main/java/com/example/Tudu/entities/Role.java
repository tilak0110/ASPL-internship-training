package com.example.Tudu.entities;

public enum Role {
    USER,
    ADMIN
}
