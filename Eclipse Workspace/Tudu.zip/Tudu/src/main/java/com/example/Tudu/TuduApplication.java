package com.example.Tudu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class TuduApplication {

	public static void main(String[] args) {
		SpringApplication.run(TuduApplication.class, args);
	}

}
