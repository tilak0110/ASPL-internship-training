package com.example.Tudu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TuduApplicationTests {

	@Test
	void contextLoads() {
	}

}
