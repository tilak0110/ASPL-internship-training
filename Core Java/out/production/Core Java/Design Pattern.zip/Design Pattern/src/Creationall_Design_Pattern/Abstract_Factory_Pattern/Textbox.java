package Creationall_Design_Pattern.Abstract_Factory_Pattern;

public interface Textbox {
    void render();
}
