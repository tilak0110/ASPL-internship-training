package Creationall_Design_Pattern.Prototype_Pattern;

public interface Prototype extends Cloneable{
    Prototype clone() throws CloneNotSupportedException ;
}
