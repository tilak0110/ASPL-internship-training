package Creationall_Design_Pattern.Factory_Design_pattern;

public interface Vehicle {
    void assemble();
}
