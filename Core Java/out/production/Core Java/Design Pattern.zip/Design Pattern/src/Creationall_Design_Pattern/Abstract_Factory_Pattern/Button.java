package Creationall_Design_Pattern.Abstract_Factory_Pattern;

public interface Button {
    void render();
}
