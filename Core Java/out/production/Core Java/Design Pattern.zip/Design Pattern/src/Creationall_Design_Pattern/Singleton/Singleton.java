package Creationall_Design_Pattern.Singleton;

public enum Singleton {
    INSTANCE ;

    public void doSomething(){
        System.out.println("singleton using enum");
    }

    //we can use this by
    public static void main(String[] args) {
        Singleton.INSTANCE.doSomething();
    }
}


