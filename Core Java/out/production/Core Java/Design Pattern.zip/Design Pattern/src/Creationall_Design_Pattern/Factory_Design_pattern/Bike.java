package Creationall_Design_Pattern.Factory_Design_pattern;

public class Bike implements Vehicle{
    @Override
    public void assemble() {
        System.out.println("Want 2 wheels , handle , bike seat");
    }
}
