package Structural_Design_Pattern.Facade_Pattern;

class PaymentProcessor {
    boolean chargePayment(double amount) {
         return true;
    }
}
