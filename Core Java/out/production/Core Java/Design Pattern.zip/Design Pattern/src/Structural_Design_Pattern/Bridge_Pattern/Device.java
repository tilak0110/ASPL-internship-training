package Structural_Design_Pattern.Bridge_Pattern;

interface Device {
    void turnOn();
    void setChannel(int channel);
}