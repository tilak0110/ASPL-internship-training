package Structural_Design_Pattern.Proxy_Pattern;

interface Image {
    void display();
}