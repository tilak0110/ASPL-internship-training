package Structural_Design_Pattern.Composite_Pattern;

public interface FileSystemComponent {
    void showDetails();
}
