package Structural_Design_Pattern.Decorator_Pattern;

public interface Coffee {
    double getCost();
    String getDescription();
}
