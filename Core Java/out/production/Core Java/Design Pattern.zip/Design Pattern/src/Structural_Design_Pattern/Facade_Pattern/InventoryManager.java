package Structural_Design_Pattern.Facade_Pattern;

class InventoryManager {
    boolean checkStock(String item) {
        return true;
    }
}