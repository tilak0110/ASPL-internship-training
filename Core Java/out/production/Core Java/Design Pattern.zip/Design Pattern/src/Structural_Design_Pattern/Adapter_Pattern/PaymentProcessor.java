package Structural_Design_Pattern.Adapter_Pattern;

interface PaymentProcessor {
    void pay(int rupees);
}