package Behavioral_Design_Pattern.Observer_Pattern;

interface Observer {
    void update(float temperature);
}
