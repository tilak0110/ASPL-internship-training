package Behavioral_Design_Pattern.Memento_Pattern;

class TextMemento {
    private final String text;

    public TextMemento(String textToSave) {
        this.text = textToSave;
    }

    public String getSavedText() {
        return text;
    }
}