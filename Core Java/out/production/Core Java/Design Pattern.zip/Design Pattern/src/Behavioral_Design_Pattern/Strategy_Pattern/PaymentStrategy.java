package Behavioral_Design_Pattern.Strategy_Pattern;

interface PaymentStrategy {
    void pay(int amount);
}
