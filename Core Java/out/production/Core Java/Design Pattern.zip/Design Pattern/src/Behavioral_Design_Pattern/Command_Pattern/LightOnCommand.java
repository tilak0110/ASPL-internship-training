package Behavioral_Design_Pattern.Command_Pattern;

class Light {
    public void on() {
        System.out.println("Light is ON");
    }

    public void off() {
        System.out.println("Light is OFF");
    }
}