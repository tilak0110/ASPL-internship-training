package Behavioral_Design_Pattern.Command_Pattern;

public interface Command {
    void execute();
    void undo();
}
