package Behavioral_Design_Pattern.Interpreter_Pattern;

interface Expression {
    boolean interpret(String context);
}