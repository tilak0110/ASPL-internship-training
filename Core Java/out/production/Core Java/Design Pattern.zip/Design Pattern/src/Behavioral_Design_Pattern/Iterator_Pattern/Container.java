package Behavioral_Design_Pattern.Iterator_Pattern;

interface Container<T> {
    Iterator<T> getIterator();
}
