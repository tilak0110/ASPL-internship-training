package remaining_topics.autoboxing;

public class AutoboxingExample3 {
    public static void main(String[] args) {
        Boolean flag = Boolean.TRUE; // ya new Boolean(true)
        if (flag) {
            System.out.println("Flag is true");
        }
    }
}
