package remaining_topics.enums.nested_class;

public class Outer {
    static class StaticNested {
        void display() {
            System.out.println("Inside Static Nested Class");
        }
    }
}
