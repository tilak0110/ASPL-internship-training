package remaining_topics.enums;

public enum Season {
    WINTER,
    SPRING,
    SUMMER,
    FALL
}