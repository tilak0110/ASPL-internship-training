package remaining_topics.expressions;

public class ExpressionBasics {
    public static void main(String[] args) {
        int a = 5;
        int b = 10;
        int sum = a + b;          // arithmetic expression
        boolean isEqual = a == b; // relational expression
        System.out.println(sum);
        System.out.println(isEqual);
    }
}
